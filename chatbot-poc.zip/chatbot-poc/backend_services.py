import os
import base64
import requests
import tempfile
from bs4 import BeautifulSoup
import PyPDF2
import docx2txt
from pptx import Presentation
import networkx as nx
from gtts import gTTS
from io import BytesIO

from pptx import Presentation
from langchain_core.documents import Document
from dotenv import load_dotenv
import os
from langchain_google_genai import ChatGoogleGenerativeAI , GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter
# from langchain.embeddings import OpenAIEmbeddings

# Global variable to store the vector database
vector_db = None

load_dotenv()

embeddings = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
llm = ChatGoogleGenerativeAI(model="models/gemini-2.5-flash")



def extract_ppt(file_path):
    """Loads a PPTX file using python-pptx and converts it to a list of LangChain Documents."""
    prs = Presentation(file_path)
    langchain_documents = []
    
    for i, slide in enumerate(prs.slides):
        slide_text = []
        slide_title = f"Slide {i + 1}"  # Default title
        
        # 1. Safely check for a title placeholder (Placeholder idx 0 is usually the title)
        title_shape = None
        for shape in slide.placeholders:
            if shape.placeholder_format.idx == 0:
                title_shape = shape
                break

        if title_shape and hasattr(title_shape, 'text') and title_shape.text:
            slide_title = title_shape.text
            
        # 2. Extract text from all shapes
        for shape in slide.shapes:
            if hasattr(shape, "text_frame") and shape.text_frame:
                text = shape.text_frame.text
                if text:
                    slide_text.append(text)
        
        # 3. Create a Document for each slide
        doc = Document(
            page_content="\n".join(slide_text),
            metadata={
                "source": file_path,
                "slide_number": i + 1, 
                "title": slide_title
            }
        )
        langchain_documents.append(doc)

    return langchain_documents

from langchain_community.document_loaders import Docx2txtLoader

def extract_word(file_path):
    loader = Docx2txtLoader(file_path)
    word_documents = loader.load()
    
    return word_documents

from langchain_community.document_loaders import PyPDFLoader

def extract_pdf(file_path):
    loader=PyPDFLoader(file_path)
    docs = loader.load()
    print(docs)


def image_to_base64(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode('utf-8')

def extract_text_from_file(file):
    """Extract text from various file types including PDF, DOCX, PPTX, and images."""
    documents = []
    file_extension = file.name.split('.')[-1].lower()
    
    try:
        # Create a temporary file to save the uploaded file content
        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_extension}") as tmp_file:
            # Write the uploaded file's content to the temporary file
            tmp_file.write(file.getvalue())
            tmp_file_path = tmp_file.name
        
        try:
            if file_extension == 'pdf':
                from langchain_community.document_loaders import PyPDFLoader
                loader = PyPDFLoader(tmp_file_path)
                documents = loader.load()
                
            elif file_extension == 'docx':
                from langchain_community.document_loaders import Docx2txtLoader
                loader = Docx2txtLoader(tmp_file_path)
                documents = loader.load()
                
            elif file_extension in ['pptx', 'ppt']:
                prs = Presentation(tmp_file_path)
                for i, slide in enumerate(prs.slides):
                    slide_text = []
                    for shape in slide.shapes:
                        if hasattr(shape, "text") and shape.text.strip():
                            slide_text.append(shape.text.strip())
                    if slide_text:
                        doc = Document(
                            page_content="\n".join(slide_text),
                            metadata={
                                "source": file.name,
                                "slide_number": i + 1
                            }
                        )
                        documents.append(doc)
                        
            elif file_extension in ['jpg', 'jpeg', 'png']:
                # For images, we'll just store the filename for now
                # In a real RAG system, you'd use OCR or a vision model here
                doc = Document(
                    page_content=f"[Image: {file.name}]",
                    metadata={"source": file.name, "type": "image"}
                )
                documents.append(doc)
                
        finally:
            # Clean up the temporary file
            try:
                os.unlink(tmp_file_path)
            except:
                pass
                
    except Exception as e:
        raise Exception(f"Error processing {file.name}: {str(e)}")
        
    return documents

from langchain_community.document_loaders import WebBaseLoader
import bs4

def extract_text_from_url(url):
    

    loader = WebBaseLoader(web_path=url)


    web_documents=loader.load()
    return web_documents
    """Extract text content from a given URL."""
    # try:
    #     response = requests.get(url, timeout=10)
    #     soup = BeautifulSoup(response.text, 'html.parser')
    #     # Remove script and style elements
    #     for script in soup(["script", "style"]):
    #         script.extract()
    #     text = soup.get_text(separator=' ', strip=True)
    #     return text
    # except Exception as e:
    #     raise Exception(f"Error processing URL {url}: {str(e)}")

from dotenv import load_dotenv


def process_documents(uploaded_files, website_urls=None):
    """
    Process all uploaded files and website URLs to create a vector database.
    
    Args:
        uploaded_files: List of uploaded file objects
        website_urls: List of website URLs (optional)
        
    Returns:
        tuple: (success: bool, message: str, db: Chroma)
    """
    try:
        all_documents = []
        
        # Process uploaded files
        for file in uploaded_files:
            try:
                docs = extract_text_from_file(file)
                if docs:
                    all_documents.extend(docs)
            except Exception as e:
                print(f"Error processing file {file.name}: {str(e)}")
                continue
        
        # Process website URLs
        if website_urls:
            for url in website_urls:
                try:
                    docs = extract_text_from_url(url)
                    if docs:
                        all_documents.extend(docs)
                except Exception as e:
                    print(f"Error processing URL {url}: {str(e)}")
                    continue
        
        if not all_documents:
            return False, "No valid documents or text content found to process.", None
        
        # Split documents into chunks
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
            is_separator_regex=False,
        )
        chunks = text_splitter.split_documents(all_documents)
        
        # Create vector store
        global vector_db
        vector_db = Chroma.from_documents(
            documents=chunks,
            embedding=embeddings,
            persist_directory="./chroma_db"
        )
        
        return True, f"Successfully processed {len(chunks)} document chunks.", vector_db
        
    except Exception as e:
        return False, f"Error processing documents: {str(e)}", None



def generate_knowledge_graph(texts):
    """Generate a knowledge graph from the provided texts."""
    # Simple keyword extraction and relationship mapping
    # In a real implementation, you'd use NLP techniques
    G = nx.Graph()
    
    # Add nodes and edges based on co-occurrence
    for i, text in enumerate(texts):
        # Simple tokenization (in reality, use NLP for better results)
        words = [word.lower() for word in text.split() if len(word) > 3][:20]  # Limit words for demo
        
        # Add nodes
        for word in words:
            if word not in G:
                G.add_node(word, title=word, group=1)
        
        # Add edges between co-occurring words
        for j in range(len(words)):
            for k in range(j + 1, len(words)):
                if G.has_edge(words[j], words[k]):
                    G[words[j]][words[k]]['weight'] += 1
                else:
                    G.add_edge(words[j], words[k], weight=1)
    
    return G

def text_to_speech(text):
    """Convert text to speech and return the audio data as base64."""
    try:
        if not text or not text.strip():
            print("Error: Empty or invalid text provided for speech synthesis")
            return None
            
        print(f"Generating speech for text (first 100 chars): {text[:100]}...")
        tts = gTTS(text=text, lang='en')
        audio_buffer = BytesIO()
        tts.write_to_fp(audio_buffer)
        audio_buffer.seek(0)
        audio_data = audio_buffer.read()
        
        if not audio_data:
            print("Error: No audio data was generated")
            return None
            
        audio_base64 = base64.b64encode(audio_data).decode('utf-8')
        print(f"Successfully generated audio (base64 length: {len(audio_base64)})")
        return audio_base64
        
    except Exception as e:
        error_msg = f"Error in text_to_speech: {str(e)}"
        print(error_msg)
        return None

def get_mock_response(user_input, db=None):
    """Generate a response using RAG with the vector database.
    
    Args:
        user_input (str): The user's query
        db: Optional vector database instance. If None, uses the global vector_db
        
    Returns:
        str: Formatted response string with search results or error message
    """
    global vector_db
    
    # Use the provided db if available, otherwise use the global vector_db
    target_db = db if db is not None else vector_db
    
    if target_db is None:
        return "Error: No vector database initialized. Please process documents first."
    
    try:
        # Get similar documents with relevance scores
        results = target_db.similarity_search_with_score(
            query=user_input,
            k=3  # Number of results to return
        )
        
        # print(results)
        
        if not results:
            return "No relevant results found for your query."
            
        # Format results as a readable string
        response = [f"Search results for: {user_input}\n"]
        for i, (doc, score) in enumerate(results, 1):
            response.append(f"\nResult {i} (Relevance: {score:.2f}):\n{doc.page_content}")
            
        return "\n".join(response)
        
    except Exception as e:
        return f"Error processing your request: {str(e)}"
    